﻿using ListagemFornecedores.Data;
using ListagemFornecedores.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ListagemFornecedores.Repositorio
{
    public class FornecedorRepositorio : IFornecedorRepositorio
    {
        private readonly BancoContext _context;

        public FornecedorRepositorio(BancoContext bancoContent)
        {
            this._context = bancoContent;
        }

        public FornecedorModel BuscarPorID(int id)
        {
            return _context.Fornecedores.FirstOrDefault(x => x.Id == id);
        }

        public List<ListasFornecedores> BuscarTodos()
        {
            var contextOptions = new DbContextOptionsBuilder<BancoContext>()
            .UseSqlServer("Server=DESKTOP-L9JG7CG\\SQLEXPRESS;Database=DB_SistemaFornecedor;User ID=sa;Password=1234;")
            .Options;

            using (var context = new BancoContext(contextOptions))
            {
                List<FornecedorModel> fornecedor = new List<FornecedorModel>();
                fornecedor = context.Fornecedores.AsNoTracking().Where(n => n != null)
                    .OrderBy(n => n.DtCad)
                        .Select(n =>
                        new FornecedorModel
                        {
                            Id = n.Id,
                            Nome = n.Nome,
                            EmpresaModel = n.EmpresaModel,
                            Documento = n.Documento,
                            Telefone = n.Telefone,
                            DtCad = n.DtCad
                        }).ToList();


                if (fornecedor != null)
                {
                    List<ListasFornecedores> fornecedoresDisplay = new List<ListasFornecedores>();
                    foreach (var x in fornecedor)
                    {
                        var fornecedorDisplay = new ListasFornecedores()
                        {
                            Id = x.Id,
                            Nome = x.Nome,
                            Documento = x.Documento,
                            Telefone = x.Telefone,
                            EmpresaNome = x.EmpresaModel.Nome,
                            DtCad = x.DtCad
                        };
                        fornecedoresDisplay.Add(fornecedorDisplay);
                    }
                    return fornecedoresDisplay;
                }
                return null;
            }
        }

        public FornecedorModel Adicionar(FornecedorModel fornecedor)
        {
            fornecedor.DtCad = DateTime.Now;
            fornecedor.EmpresaModel = _context.Empresas.Find(fornecedor.EmpresaId);
            _context.Fornecedores.Add(fornecedor);
            _context.SaveChanges();
            return fornecedor;
        }

        public FornecedorModel Atualizar(FornecedorModel fornecedorDB)
        {
            FornecedorModel fornecedor = BuscarPorID(fornecedorDB.Id);

            if (fornecedorDB == null) throw new Exception("Houve um erro na atualização do fornecedor!");

            fornecedorDB.Nome = fornecedor.Nome;
            fornecedorDB.Documento = fornecedor.Documento;
            

            _context.Fornecedores.Update(fornecedorDB);
            _context.SaveChanges();

            return fornecedorDB;
        }

        public bool Apagar(int id)
        {
            FornecedorModel fornecedorDB = BuscarPorID(id);

            if (fornecedorDB == null) throw new Exception("Houve um erro na deleção do fornecedor!");

            _context.Fornecedores.Remove(fornecedorDB);
            _context.SaveChanges();

            return true;
        }

        public FornecedorViewModelcs AdicionarEmpresas()
        {
            var emp = new ListaEmpresasRepositorio();
            var empresas = new FornecedorViewModelcs()
            {
                Empresas = emp.GetEmpresas()
            };
            return empresas;
        }

    }
}
