﻿using ListagemFornecedores.Data;
using ListagemFornecedores.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ListagemFornecedores.Repositorio
{
    public class EmpresaRepositorio : IEmpresaRepositorio
    {
        private readonly BancoContext _context;

        public EmpresaRepositorio(BancoContext bancoContent)
        {
            this._context = bancoContent;
        }

        public EmpresaModel BuscarPorID(int id)
        {
            return _context.Empresas.FirstOrDefault(x => x.Id == id.ToString());
        }

        public List<EmpresaModel> BuscarTodos()
        {
            return _context.Empresas.ToList();
        }

        public EmpresaModel Adicionar(EmpresaModel empresa)
        {
            _context.Empresas.Add(empresa);
            _context.SaveChanges();
            return empresa;
        }

        public EmpresaModel Atualizar(EmpresaModel empresa)
        {
            EmpresaModel empresaDB = BuscarPorID(Convert.ToInt32(empresa.Id));

            if (empresaDB == null) throw new Exception("Houve um erro na atualização da empresa!");

            empresaDB.Nome = empresa.Nome;
            empresaDB.CNPJ = empresa.CNPJ;
            empresaDB.UF = empresa.UF;

            _context.Empresas.Update(empresaDB);
            _context.SaveChanges();

            return empresaDB;
        }

        public bool Apagar(int id)
        {
            EmpresaModel empresaDB = BuscarPorID(id);

            if (empresaDB == null) throw new Exception("Houve um erro na deleção da empresa!");

            _context.Empresas.Remove(empresaDB);
            _context.SaveChanges();

            return true;
        }
    }
}
