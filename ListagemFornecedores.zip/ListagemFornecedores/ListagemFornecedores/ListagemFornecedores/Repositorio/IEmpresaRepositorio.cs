﻿using ListagemFornecedores.Models;
using System.Collections.Generic;

namespace ListagemFornecedores.Repositorio
{
    public interface IEmpresaRepositorio
    {
        List<EmpresaModel> BuscarTodos();
        EmpresaModel BuscarPorID(int id);
        EmpresaModel Adicionar(EmpresaModel empresa);
        EmpresaModel Atualizar(EmpresaModel empresa);
        bool Apagar (int id);
    }
}
