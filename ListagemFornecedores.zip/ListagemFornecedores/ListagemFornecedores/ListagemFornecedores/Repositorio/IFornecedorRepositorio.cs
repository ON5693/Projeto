﻿using ListagemFornecedores.Models;
using System.Collections.Generic;

namespace ListagemFornecedores.Repositorio
{
    public interface IFornecedorRepositorio
    {
        List<ListasFornecedores> BuscarTodos();
        FornecedorModel BuscarPorID(int id);
        FornecedorModel Adicionar(FornecedorModel fornecedor);
        FornecedorModel Atualizar(FornecedorModel fornecedor);
        FornecedorViewModelcs AdicionarEmpresas();
        bool Apagar (int id);
    }
}
