﻿using ListagemFornecedores.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ListagemFornecedores.Repositorio
{
    public class ListaEmpresasRepositorio
    {
        public IEnumerable<SelectListItem> GetEmpresas()
        {
            var contextOptions = new DbContextOptionsBuilder<BancoContext>()
            .UseSqlServer("Server=DESKTOP-L9JG7CG\\SQLEXPRESS;Database=DB_SistemaFornecedor;User ID=sa;Password=1234;")
            .Options;

            using (var context = new BancoContext(contextOptions))
            {
                List<SelectListItem> empresas = context.Empresas.AsNoTracking().Where(n => n != null)
                    .OrderBy(n => n.Id)
                        .Select(n =>
                        new SelectListItem
                        {
                            Value = n.Id.ToString(),
                            Text = n.Nome
                        }).ToList();
                
                    var emp = new SelectListItem()
                    {
                        Value = null,
                        Text = "--- selecione empresa ---"
                    };
                    empresas.Insert(0, emp);

                    return new SelectList(empresas, "Value", "Text");
            }
        }
    }
}
