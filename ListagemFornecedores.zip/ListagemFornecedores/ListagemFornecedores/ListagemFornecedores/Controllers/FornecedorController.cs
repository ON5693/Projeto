﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ListagemFornecedores.Models;
using ListagemFornecedores.Repositorio;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ListagemFornecedores.Controllers
{
    public class FornecedorController : Controller
    {
        private readonly IFornecedorRepositorio _fornecedorRepositorio;
        public FornecedorController(IFornecedorRepositorio fornecedorRepositorio)
        {
            _fornecedorRepositorio = fornecedorRepositorio;
        }

        public IActionResult Index()
        {
            List<ListasFornecedores> fornecedor = _fornecedorRepositorio.BuscarTodos();

            return View(fornecedor);
        }

        public IActionResult Criar()
        {
            FornecedorViewModelcs empresas = _fornecedorRepositorio.AdicionarEmpresas();
            return View(empresas);
        }

        public IActionResult Editar(int id)
        {
            FornecedorModel fornecedor = _fornecedorRepositorio.BuscarPorID(id);
            return View(fornecedor);
        }

        public IActionResult ApagarConfirmacao(int id)
        {
            FornecedorModel fornecedor = _fornecedorRepositorio.BuscarPorID(id);
            return View(fornecedor);
        }

        public IActionResult Apagar(int id)
        {
            try
            {
                bool apagado = _fornecedorRepositorio.Apagar(id);

                if (apagado) TempData["MensagemSucesso"] = "fornecedor apagado com sucesso!"; 
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos apagar o fornecedor, tente novamante, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Criar(FornecedorModel fornecedor)
        {
            try
            {
                var cpf = false;
                var emp = new ListaEmpresasRepositorio();
                var forn = new FornecedorViewModelcs()
                {
                    Id = fornecedor.Id.ToString(),
                    EmpresaId = fornecedor.EmpresaId,
                    Empresas = emp.GetEmpresas(),
                    Nome = fornecedor.Nome,
                    Documento = fornecedor.Documento,
                    RG = fornecedor.RG,
                    DtNas = fornecedor.DtNas,
                    DtCad = fornecedor.DtCad,
                    Telefone = fornecedor.Telefone,
                    Telefone2 = fornecedor.Telefone2,
                    Telefone3 = fornecedor.Telefone3
                };

                if (string.IsNullOrEmpty(forn.Nome))
                    ModelState.AddModelError("Nome", "O nome é obrigatório");

                if (string.IsNullOrEmpty(forn.Documento))
                    ModelState.AddModelError("Documento", "O CPF/CNPJ obrigatório");
                else
                {
                    if (forn.Documento.Length < 12)
                    {
                        cpf = true;
                    }
                }

                if (cpf)
                {
                    if ((forn.DtNas.Year > 2004) || (forn.RG == null))
                    {
                        ModelState.AddModelError("DtNas", "Obrigatório ser maior que 18 anos");
                        ModelState.AddModelError("RG", "RG deve ser informada");
                    }
                    else
                    {
                        cpf = false;
                    }
                }
              
                if (string.IsNullOrEmpty(forn.Telefone))
                    ModelState.AddModelError("Telefone", "O Telefone é obrigatório.");
                

                if (ModelState.IsValid)
                {
                    fornecedor = _fornecedorRepositorio.Adicionar(fornecedor);

                    TempData["MensagemSucesso"] = "Fornecedor cadastrado com sucesso!";
                    return RedirectToAction("Index");
                }
                
                return View(forn);
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos cadastrar o fornecedor, por favor preencha todos os campos, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Editar(FornecedorModel fornecedor)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    fornecedor = _fornecedorRepositorio.Atualizar(fornecedor);
                    TempData["MensagemSucesso"] = "Fornecedor alterado com sucesso!";
                    return RedirectToAction("Index");
                }

                return View(fornecedor);
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos atualizar o fornecedor, tente novamante, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }
    }
}
