﻿using ListagemFornecedores.Models;
using ListagemFornecedores.Repositorio;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace ListagemFornecedores.Controllers
{
    public class EmpresaController : Controller
    {
        private readonly IEmpresaRepositorio _empresaRepositorio;

        public EmpresaController(IEmpresaRepositorio empresaRepositorio)
        {
            _empresaRepositorio = empresaRepositorio;
        }

        public IActionResult Index()
        {
            List<EmpresaModel> empresa = _empresaRepositorio.BuscarTodos();

            return View(empresa);
        }

        public IActionResult Criar()
        {
            return View();
        }

        public IActionResult Editar(int id)
        {
            EmpresaModel empresa = _empresaRepositorio.BuscarPorID(id);
            return View();
        }

        public IActionResult ApagarConfirmacao(int id)
        {
            EmpresaModel empresa = _empresaRepositorio.BuscarPorID(id);
            return View();
        }

        public IActionResult Apagar(int id)
        {
            try
            {
                bool apagado = _empresaRepositorio.Apagar(id);

                if (apagado) TempData["MensagemSucesso"] = "empresa apagada com sucesso!";
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos apagar a empresa, tente novamante, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Criar(EmpresaModel empresa)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    empresa = _empresaRepositorio.Adicionar(empresa);

                    TempData["MensagemSucesso"] = "Empresa cadastrado com sucesso!";
                    return RedirectToAction("Index");
                }

                return View(empresa);
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos cadastrar a empresa, tente novamante, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Editar(EmpresaModel empresa)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    empresa = _empresaRepositorio.Atualizar(empresa);
                    TempData["MensagemSucesso"] = "Empresa alterada com sucesso!";
                    return RedirectToAction("Index");
                }

                return View(empresa);
            }
            catch (Exception erro)
            {
                TempData["MensagemErro"] = $"Ops, não conseguimos atualizar o fornecedor, tente novamante, detalhe do erro: {erro.Message}";
                return RedirectToAction("Index");
            }
        }
    }
}
