﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ListagemFornecedores.Models
{
    public class FornecedorViewModelcs
    {
        public string Id { get; set; }
        
        [Required(ErrorMessage = "Digite o nome")]
        public string Nome { get; set; }
        
        [Required(ErrorMessage = "Selecione a empresa")]
        public string EmpresaId { get; set; }
        
        [Required(ErrorMessage = "Digite o CPF ou CNPJ")]
        public string Documento { get; set; }
    
        [Required(ErrorMessage = "Digite o telefone com DDD ex:1199999999")]
        public string Telefone { get; set; }
        
        public string Telefone2 { get; set; }
        
        public string Telefone3 { get; set; }
        
        [DisplayFormat(DataFormatString = "mm/dd/yyyy")]
        public DateTime DtCad { get; set; }
        
        public int? RG { get; set; }
        
        [DisplayFormat(DataFormatString = "mm/dd/yyyy")]
        [Required(ErrorMessage = "Selecione a data de nascimento")]
        public DateTime DtNas { get; set; }

        public IEnumerable<SelectListItem> Empresas { get; set; }
    }
}
