﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ListagemFornecedores.Models
{
    public class ListasFornecedores
    {
        [Display(Name = "Codigo")]
        public int Id { get; set; }

        [Display(Name = "Fornecedor")]
        [Required(ErrorMessage = "Digite o nome")]
        public string Nome { get; set; }

        [Display(Name = "Empresa")]
        public string EmpresaNome { get; set; }

        [Display(Name = "CPF/CNPJ")]
        [Required(ErrorMessage = "Digite o CPF ou CNPJ")]
        public string Documento { get; set; }

        [Display(Name = "Telefone")]
        [Required(ErrorMessage = "Digite o telefone com DDD ex:1199999999")]
        public string Telefone { get; set; }

        [Display(Name = "dataCadastro")]
        public DateTime DtCad { get; set; }
    }
}
