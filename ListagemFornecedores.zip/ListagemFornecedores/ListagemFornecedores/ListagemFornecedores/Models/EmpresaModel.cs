﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ListagemFornecedores.Models
{
    public class EmpresaModel
    {
        [Key]
        public string Id { get; set; }
        [Required(ErrorMessage = "Digite o nome da empresa")]
        public string Nome { get; set; }
        [Required(ErrorMessage = "Digite a UF onde está localizada a empresa")]
        public string UF { get; set; }
        [Required(ErrorMessage = "Digite o CNPJ")]
        public string CNPJ { get; set; }
    }
}
