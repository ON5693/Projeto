﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ListagemFornecedores.Models
{
    [Table("Fornecedores")]
    public class FornecedorModel
    {
        [Key()]
        [Column("Id")]
        public int Id { get; set; }

        [Column("EmpresaId")]
        public string EmpresaId { get; set; }
        public virtual EmpresaModel EmpresaModel { get; set; }

        [Column("Nome")]
        public string Nome { get; set; }

        [Column("Documento")]
        public string Documento { get; set; }

        [Column("RG")]
        [Display(Name = "RG")]
        public int? RG { get; set; }

        [Column("dataNascimento")]
        public DateTime DtNas { get; set; }

        [Column("dataCadastro")]
        [Display(Name = "dataCadastro")]
        public DateTime DtCad { get; set; }

        [Column("Telefone")]
        public string Telefone { get; set; }

        [Column("Telefone2")]
        public string Telefone2 { get; set; }

        [Column("Telefone3")]
        public string Telefone3 { get; set; }
        
    }
    
}
