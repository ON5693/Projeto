﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ListagemFornecedores.Models;
using Microsoft.EntityFrameworkCore;

namespace ListagemFornecedores.Data
{
    public class BancoContext : DbContext
    {
        public BancoContext(DbContextOptions<BancoContext> options) :
            base(options)
        {
        }
        
        public DbSet<EmpresaModel> Empresas { get; set; }
        public DbSet<FornecedorModel> Fornecedores { get; set; }
    }
}
   